
drop table dbo.employees;

go
CREATE TABLE employees
( employee_id INT NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  first_name VARCHAR(50),
  salary MONEY
);



GO

insert into dbo.employees
(employee_id , last_name , first_name , salary )
VALUES (1001 , 'Smith' , 'John' , 62000  );
go
insert into dbo.employees
(employee_id , last_name , first_name , salary )
VALUES(1002 , 'Anderson' , 'Jane' , 57500  );

go

insert into dbo.employees
(employee_id , last_name , first_name , salary )
VALUES(1003 , 'Everest' , 'Brad' , 71000) , 
(1004 , 'Horvath' , 'Jack' , 42000)


GO
select * from employees