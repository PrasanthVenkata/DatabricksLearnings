drop table dbo.stg_employees;

go
CREATE TABLE stg_employees
( employee_id INT NOT NULL,
  last_name VARCHAR(50) NOT NULL,
  first_name VARCHAR(50),
  salary MONEY,
  dept_no VARCHAR(10) null
);


select * from stg_employees